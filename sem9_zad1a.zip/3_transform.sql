-- Active: 1791381172066@@127.0.0.1@5432@movielens_elt

\set on_error_stop on \encoding utf8

create schema if not exists gold;

create table gold.dim_user (
    user_id int not null unique,
    gender char(1) not null check (gender in ('M', 'F')),
    zip_code varchar(10) not null,
    age_group varchar(20) not null,
    occupation varchar(50) not null
);

create table gold.dim_movie (
    movie_id int not null unique,
    title varchar(200) not null,
    release_year int not null,
    genre_name varchar(200) not null
);

create table gold.dim_date (
    date_id int not null primary key,
    rated_at date not null unique,
    day int not null,
    month int not null,
    year int not null,
    day_of_week int not null,
    day_name varchar(10) not null,
    week int not null,
    month_name varchar(10) not null,
    quarter int not null
);

create table gold.dim_time (
    time_id int primary key,
    rated_time time not null unique,
    hour int not null,
    minute int not null,
    second int not null,
    time_of_day varchar(10) not null
);

create table gold.fact_rating (
    rating_id int primary key,
    user_id int not null references gold.dim_user (user_id),
    movie_id int not null references gold.dim_movie (movie_id),
    date_id int not null references gold.dim_date (date_id),
    time_id int not null references gold.dim_time (time_id),
    rating numeric(2, 1) not null check (rating between 1 and 5),
    rating_count int not null, 
    rating_percentage int not null
);

create index on gold.fact_rating (user_id);
create index on gold.fact_rating (movie_id);
create index on gold.fact_rating (date_id);
create index on gold.fact_rating (time_id);

begin;

truncate gold.fact_rating, gold.dim_user, gold.dim_movie, gold.dim_date, gold.dim_time;

insert into gold.dim_user (user_id, gender, zip_code, age_group, occupation)
    select 
        u.user_id, 
        u.gender, 
        u.zip_code, 
        coalesce(ag.name, 'unknown'), 
        coalesce(o.name, 'unknown')
    from silver.stg_users u 
    left join silver.stg_age_group ag on ag.age_group_id = u.age
    left join silver.stg_occupations o on o.occupation_id = u.occupation_id
    order by u.user_id;

insert into gold.dim_movie(movie_id, title, release_year, genre_name)
    select 
        m.movie_id, 
        m.title, 
        m.release_year::int, 
        coalesce(g.genre_name, 'unknown')
    from silver.stg_movies m
    left join (
        select gm.movie_id, string_agg(
            g.genre_name, ', '
            order by g.genre_name
        ) as genre_name
        from silver.stg_genres_movies gm
        join silver.stg_genres g on g.genre_id = gm.genre_id
        group by gm.movie_id 
    ) g on g.movie_id = m.movie_id
    order by m.movie_id;

insert into gold.dim_date
    select
        to_char(d, 'YYYYMMDD')::int as date_id,
        d as rated_at,
        extract(day from d)::int as day,
        extract(month from d)::int as month,
        extract(year from d)::int as year,
        extract(isodow from d)::int as day_of_week,
        trim(to_char(d, 'Day')) as day_name,
        extract(week from d)::int as week,
        trim(to_char(d, 'Month')) as month_name,
        extract(quarter from d)::int as quarter
    from generate_series(
        (select min(rated_at)::date from silver.stg_ratings),
        (select max(rated_at)::date from silver.stg_ratings),
        interval '1 day'
    ) as gs(d);

insert into gold.dim_time
    select
        to_char(make_interval(secs => sec), 'HH24MISS')::int as time_id,
        make_time(sec / 3600, (sec / 60) % 60, sec % 60) as rated_time,
        sec / 3600 as hour,
        (sec / 60) % 60 as minute,
        sec % 60 as second,
        case
            when sec / 3600 between 5 and 11 then 'morning'
            when sec / 3600 between 12 and 17 then 'afternoon'
            when sec / 3600 between 18 and 21 then 'evening'
            else 'night'
        end as time_of_day
    from generate_series(0, 86399) as gs(sec);

insert into gold.fact_rating (rating_id, user_id, movie_id, date_id, time_id, rating, rating_count, rating_percentage)
    select 
        r.rating_id, 
        r.user_id, 
        r.movie_id, 
        d.date_id, 
        t.time_id, 
        r.rating, 
        count(*) over (partition by r.movie_id) as rating_count,
        round(count(*) over (partition by r.movie_id, r.rating) * 100.0 / count(*) over (partition by r.movie_id))::int as rating_percentage    
    from silver.stg_ratings r
    join gold.dim_date d on d.rated_at = r.rated_at::date
    join gold.dim_time t on t.rated_time = r.rated_at::time
    order by r.rating_id;

commit;